package com.example.countapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    int c=0;
    @SuppressLint("MissingInflatedId")
    @Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.tx1);
    }

    public void toast(View view) {
        Toast.makeText(this,
                "welcome", Toast.LENGTH_SHORT).show();
    }
    public void count(View view){
        c++;
        tv.setText(""+c);
    }
    public void decr(View view){
        c--;
        tv.setText(""+c);
    }
}